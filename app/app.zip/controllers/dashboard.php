<?php

class Dashboard extends Controller {
	// public function index()
	// {
	// 		$data['title'] = 'IT-Asset Management Dashboard';
	// 		$this->view('templates/header', $data);
	// 		$this->view('dasboard/index', $data);
	// 		$this->view('templates/footer');
		
	// }
}